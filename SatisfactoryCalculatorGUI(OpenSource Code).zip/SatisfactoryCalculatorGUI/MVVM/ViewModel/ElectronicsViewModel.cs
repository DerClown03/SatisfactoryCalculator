﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SatisfactoryCalculatorGUI.MVVM.ViewModel
{
    public class ElectronicsViewModel
    {
    }
}
