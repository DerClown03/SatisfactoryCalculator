﻿using SatisfactoryCalculatorGUI.core;
using SatisfactoryCalculatorGUI.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SatisfactoryCalculatorGUI.MVVM.Model
{
    public class SatisfactoryCalculator : ObservableObject
    {
        public static string[,] neededQuantitys = new string[1, 2];
        public static string[,] recipesTree = new string[1, 2];
        public static string[,] neededRecipes = new string[1, 2];
        public static double[] neededMachines = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public static string[] machines = new string[] { "smelter", "foundry", "constructor", "assembler", "manufacturer", "refinery", "blender", "particle_accelerator", "packager" };
        public static string[] defaultResources = new string[] { "limestone", "iron_ore", "copper_ore", "caterium_ore", "coal", "raw_quartz", "sulfur", "bauxit", "uranium", "water", "crude_oil", "nitrogen_gas", "uranium_waste" };
        public static bool RecipeIndexRecived = false;
        public static int RecipeIndex = 0;
        public static bool isRunning = false;
        static CancellationTokenSource cts = new CancellationTokenSource();

        public static event EventHandler<EventArgs> OnRecipesListUpdated;
        public static event EventHandler<OnCalculationFinishedEventArgs> OnCalculationFinished;

        public class OnCalculationFinishedEventArgs : EventArgs
        {
            public string[] CountedMachines;
            public string[,] ProducedQuantitys;
            public string[,] NeededMachinesInTree;
            public string[,] NeededMachinesInList;
        }

        public SatisfactoryCalculator()
        {
            MainViewModel.OnRecipeChosen += Testing_OnRecipeChosen;
            MainViewModel.OnStartCalculating += Testing_OnStartCalculating;
            MainViewModel.OnCancelCalculation += Testing_OnCancelCalculation;
            MainViewModel.OnResetCancellationToken += Testing_OnResetCancellationToken;
        }

        public static void ResetVariables()
        {
            neededQuantitys = new string[1, 2];
            recipesTree = new string[1, 2];
            neededRecipes = new string[1, 2];
            neededMachines = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            machines = new string[] { "smelter", "foundry", "constructor", "assembler", "manufacturer", "refinery", "blender", "particle_accelerator", "packager" };
            defaultResources = new string[] { "limestone", "iron_ore", "copper_ore", "caterium_ore", "coal", "raw_quartz", "sulfur", "bauxit", "uranium", "water", "crude_oil", "nitrogen_gas", "uranium_waste" };
        }

    private void Testing_OnResetCancellationToken(object sender, EventArgs e)
        {
            cts.Dispose();
            cts = new CancellationTokenSource();
        }

        private void Testing_OnCancelCalculation(object sender, EventArgs e)
        {
            cts.Cancel();
            isRunning = false;
        }

        static void NotMain(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine();

            string item = askForItem(); // Ask for Item that should be produced
            if (!checkForRecipe(item))  // Check if the recipe for that item exsists
            {
                Console.WriteLine("No recipe found!");
            }
            string[] chosenRecipeCoords = askForRecipe(item); // Show all available recipes and ask the user wich should be used
            double quantity = askForQuantity();               // Ask the user how many items should be produced
            Console.WriteLine("starting");                    // test 
            //calculate(item, quantity, chosenRecipeCoords);    // Start to calculate all needed machines
            int counter = 0;
            foreach (double i in neededMachines)
            {
                if (i != 0)
                {
                    Debug.Write(i + " ");
                    Debug.Write(machines[counter] + "s\n");
                }
                counter++;
            }
            Debug.WriteLine("");
            printArray2D(neededQuantitys);
            Debug.WriteLine("");
            printArray2D(recipesTree);
        }

        static string[,] saveToArray(string item, int quantity, string[,] array)
        {
            if (itemExists(item, array) != -1)
            {
                int index = itemExists(item, array);
                int currentQuantity = Convert.ToInt32(array[index, 1]);
                array[itemExists(item, array), 1] = Convert.ToString(currentQuantity + quantity);
            }
            else
            {
                array = addToArray(item, quantity, array);
            }
            return array;
        }

        static string[,] addToArray(string item, int quantity, string[,] array)
        {
            int lines = array.GetLength(0);
            string[,] newArray = new string[lines + 1, 2];

            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    newArray[i, j] = array[i, j];
                }
            }
            int x = newArray.GetLength(0) - 2;
            newArray[x, 0] = item;
            newArray[x, 1] = quantity.ToString();

            return newArray;
        }

        static int itemExists(string item, string[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                if (array[i, 0] == item)
                {
                    return i;
                }
            }

            return -1;
        }

        // Recusive function to loop through all needed recipes
        static async Task calculate(string item, double quantity, string[] RecipeCoords, ObservableCollection<LoadedRecipesModel> loadedRecipes, string depth = "", bool last = true, bool first = true)
        {
            if (checkForRecipe(item)) // Check if the recipe for that item exsists. If not the function exits
            {
                // Use outputs to calculate the needed machines
                string[,] outputs = getOutputs(RecipeCoords);  // Get the outputs the machine produces
                string[] savedOutput = new string[2];
                for (int i = 0; i < outputs.GetLength(0); i++) // Get just the searched <item> from the list of outputs
                {
                    if (outputs[i, 0] == item)
                    {
                        savedOutput = getSlice(outputs, i);
                        break;
                    }
                }
                double machinesDouble = quantity / StringToDouble(savedOutput[1]);   // Calculate the amount of needed machines
                double machinesCount = Math.Ceiling(machinesDouble);                                     //  for the quantity that should be produced
                int machine = Convert.ToInt32(RecipeCoords[0]);                                          // Get machine (int) for the current recipe

                string output = depth;
                if (first == false)
                {
                    if (last)
                    {
                        output += "└──";
                        depth += "   ";
                    }
                    else
                    {
                        output += "├──";
                        depth += "│  ";
                    }
                }

                neededMachines[machine] = neededMachines[machine] + machinesCount;                   // Save the number of needed machines
                recipesTree = saveToArray(output + StringFormatting.ToReadableItem(item) + " in " + machinesCount + " " + StringFormatting.ToReadableItem(machines[machine] + "s") + ":", Convert.ToInt32(quantity), recipesTree);
                neededRecipes = saveToArray(StringFormatting.ToReadableItem(machines[machine]) + ":" + StringFormatting.ToReadableItem(item), Convert.ToInt32(machinesCount), neededRecipes);
                // Use inputs to iterate through all needed machines / recipes
                string[,] inputs = getInputs(RecipeCoords); // Get the inputs that the machine needs
                                                            // (example) structure inputs { { string item1, int quantity1 }, 
                                                            //                              { string item2, int quantity2 } }
                                                            //                              ...

                for (int i = 0; i < inputs.GetLength(0); i++) // Go through every needed item
                {
                    double newQuantity = StringToDouble(inputs[i, 1]) * machinesCount; // Calculate the needed quantity of the item from input
                                                                                                           //  with the machines needed for the quantity of output
                    if (IsDefaultResource(inputs[i, 0]))
                    {
                        neededQuantitys = saveToArray(StringFormatting.ToReadableItem(inputs[i, 0]), Convert.ToInt32(newQuantity), neededQuantitys);
                    }
                    string[] chosenRecipeCoords = await RecipesToList(inputs[i, 0], loadedRecipes); // Ask user wich recipe should be used for the needed item
                    Console.WriteLine("");
                    if (!(chosenRecipeCoords[0] == "error"))                  // Check if user doesn't want to use a recipe (example: item coal)
                    {
                        bool testnext = false;
                        if (i != inputs.GetLength(0) - 1)
                        {
                            testnext = IsDefaultResource(inputs[i + 1, 0]);
                        }

                        bool lastitem = i == inputs.GetLength(0) - 1 || testnext;
                        await calculate(inputs[i, 0], newQuantity, chosenRecipeCoords, loadedRecipes, depth, lastitem, false); // Start the next iteration with the new values
                    }
                }
            }
        }

        public static double StringToDouble(string numberstr)
        {
            double output = 0;
            string[] split = numberstr.Split(',', '.');
            output = Convert.ToInt32(split[0]);
            if (split.GetLength(0) >= 2)
            {
                double dec = 10;
                for (int i = 0; i < split[1].Length - 1; i++)
                {
                    dec *= 10;
                }
                output += Convert.ToInt32(split[1]) / dec;
            }

            return output;
        }

        static bool IsDefaultResource(string item)
        {
            foreach (string resource in defaultResources)
            {
                if (item == resource)
                {
                    return true;
                }
            }
            return false;
        }

        // Function to check if a recipe with an output of <item> exists
        static bool checkForRecipe(string item)
        {
            string[,] recipes = searchrecipes(item); // Get all recipies for <item>
            recipes = deleteEmpty2D(recipes);        // Delete all empty strings
            if (recipes.GetLength(0) == 0)           // Check if the whole array is empty / has no elements
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        // Function to ask how many parts from the choosen item should be produced
        static double askForQuantity()
        {
            Console.Write("Choose quantity (items per minute): ");
            double quantity = Convert.ToDouble(Console.ReadLine());
            return quantity;
        }

        // Function to ask the user wich recipe they want to use in their pruduction line
        static string[] askForRecipe(string item)
        {
            string[,] recipes = searchrecipes(item); // Get all recipies for <item>
            recipes = deleteEmpty2D(recipes);        // Delete all empty strings
            if (recipes.GetLength(0) == 0 || IsDefaultResource(item))           // Return an error if the array has no elements (item does not exist)
            {
                string[] end = new string[] { "error" };
                return end;
            }
            for (int i = 0; i < recipes.GetLength(0); i++) // Print every recipe from <item>
            {
                string[] recipe = getSlice(recipes, i);          // Get single coordinates from <recipes>
                string[] singlerecipe = getSingleRecipe(recipe); // Get recipe from the coords
                Console.Write("\n" + (i + 1) + ": ");            // Write the recipe in a readable way
                Console.Write(makeString(singlerecipe));
            }
            Console.Write("\nChoose recipe (1 - {0}): ", recipes.GetLength(0)); // Let the user choose wich recipe to use
            //int chosenRecipeNum = Convert.ToInt32(Console.ReadLine()) - 1;
            Debug.WriteLine("Waiting for Index!");
            while (!RecipeIndexRecived) ;

            int chosenRecipeNum = RecipeIndex;
            Debug.WriteLine("got Index! " + chosenRecipeNum);

            if (chosenRecipeNum == -1) // Return an error if the user decides to use no recipe
            {
                string[] end = new string[] { "error" };
                return end;
            }
            string[] chosenRecipeCoords = getSlice(recipes, chosenRecipeNum); // Save the coords for the choosen recipe
            return chosenRecipeCoords; // structure of coords { int machine, int lineInDatabase }
        }

        public async void Testing_OnStartCalculating(object sender, MainViewModel.OnStartCalculatingEventArgs e)
        {
            if (!isRunning)
            {
                isRunning = true;
                try
                {
                    ResetVariables();
                    string[] recipeCoords = await RecipesToList(e.Item, e.LoadedRecipesCollection);
                    await calculate(e.Item, e.ItemQuantity, recipeCoords, e.LoadedRecipesCollection);

                    OnCalculationFinishedEventArgs CalculationFinishedArgs = new OnCalculationFinishedEventArgs
                    {
                        CountedMachines = NeededMachines(),
                        ProducedQuantitys = neededQuantitys,
                        NeededMachinesInTree = recipesTree,
                        NeededMachinesInList = neededRecipes
                    };


                    //int counter = 0;
                    //foreach (double i in neededMachines)
                    //{
                    //    if (i != 0)
                    //    {
                    //        Debug.Write(i + " ");
                    //        Debug.Write(machines[counter] + "s\n");
                    //    }
                    //    counter++;
                    //}
                    //Debug.WriteLine("");
                    //printArray2D(neededQuantitys);
                    //Debug.WriteLine("");
                    //printArray2D(recipesTree);
                    //Debug.WriteLine("");
                    //printArray2D(neededRecipes);

                    OnCalculationFinished?.Invoke(this, CalculationFinishedArgs);
                }
                catch (OperationCanceledException)
                {
                    Debug.WriteLine("Calculation Cancelled");
                }
            }
        }

        static string[] NeededMachines()
        {
            string[] combined = new string[neededMachines.GetLength(0)];
            int counter = 0;
            foreach (double i in neededMachines)
            {
                if (i != 0)
                {
                    string readableMachine = StringFormatting.ToReadableItem(machines[counter]);
                    combined[counter] = $"{i} {readableMachine}s";
                }
                counter++;
            }
            
            return combined;
        }

        public void Testing_OnRecipeChosen(object sender, MainViewModel.OnRecipeChosenEventArgs e)
        {
            RecipeIndexRecived = true;
            RecipeIndex = e.ChosenRecipeIndex;
        }

        public static void WaitForButtonPress(CancellationToken cancellation)
        {
            while (!RecipeIndexRecived)
            {
                cancellation.ThrowIfCancellationRequested();
            }
            return;
        }

        public static async Task<string[]> RecipesToList(string item, ObservableCollection<LoadedRecipesModel> loadedRecipes)
        {
            string[,] recipes = searchrecipes(item); // Get all recipies for <item>
            recipes = SortRecipesToNormal(recipes);  // Delete all empty strings and sort the array so that the normal recipe is at the top
            if (recipes.GetLength(0) == 0 || IsDefaultResource(item))           // Return an error if the array has no elements (item does not exist)
            {
                string[] end = new string[] { "error" };
                return end;
            }
            loadedRecipes.Clear();
            for (int i = 0; i < recipes.GetLength(0); i++) // Print every recipe from <item>
            {
                string[] recipe = getSlice(recipes, i);          // Get single coordinates from <recipes>
                string[] singlerecipe = getSingleRecipe(recipe); // Get recipe from the coords
                LoadedRecipesModel ThisRecipe = RecipeToObject(singlerecipe, recipe[0]);
                loadedRecipes.Add(ThisRecipe);
                object s = 1;
                OnRecipesListUpdated?.Invoke(s, EventArgs.Empty);
            }

            await Task.Run(() => WaitForButtonPress(cts.Token));
            int chosenRecipeNum = RecipeIndex;
            RecipeIndexRecived = false;
            RecipeIndex = 0;

            string[] chosenRecipeCoords = getSlice(recipes, chosenRecipeNum); // Save the coords for the choosen recipe
            return chosenRecipeCoords; // structure of coords { int machine, int lineInDatabase }
        }

        static string[,] SortRecipesToNormal(string[,] recipes)
        {
            recipes = deleteEmpty2D(recipes);
            string[,] newRecipes = new string[recipes.GetLength(0), 2];

            if (recipes.GetLength(0) == 0)
            {
                return recipes;
            }

            int NormalRecipeIndex = 0;
            for (int i = 0; i < recipes.GetLength(0); i++)
            {
                string[] RecipeCoords = getSlice(recipes, i);
                string[] Recipe = getSingleRecipe(RecipeCoords);
                Recipe = deleteEmpty1D(Recipe);
                int AlternateIndex = Recipe.Length - 2;
                if (Recipe[AlternateIndex] == "n")
                {
                    NormalRecipeIndex = i;
                    break;
                }
            }

            for (int i = 0; i < 2; i++)
            {
                newRecipes[0, i] = recipes[NormalRecipeIndex, i];
            }

            int count = 0;
            for (int i = 0; i < recipes.GetLength(0); i++)
            {
                count++;
                for (int j = 0; j < recipes.GetLength(1); j++)
                {
                    if (i != NormalRecipeIndex)
                    {
                        newRecipes[count, j] = recipes[i, j];
                    }
                    else
                    {
                        i++;
                        j--;
                        if (i == recipes.GetLength(0))
                        {
                            return newRecipes;
                        }
                    }
                }
            }

            return newRecipes;
        }

        static LoadedRecipesModel RecipeToObject(string[] recipe, string machine)
        {
            LoadedRecipesModel Recipe = new LoadedRecipesModel();
            int InputsCounter = Convert.ToInt32(recipe[0]);
            int OutputsCounter = Convert.ToInt32(recipe[1]);
            int machineNumber = Convert.ToInt32(machine);

            Recipe.Machine = $"/images/machines/{machines[machineNumber]}.png";

            switch (InputsCounter)
            {
                case 1:
                    Recipe.Input1 = $"/images/items/{recipe[3]}.png";
                    Recipe.InputQuantity1 = $"{recipe[4]}/min";
                    break;
                case 2:
                    Recipe.Input1 = $"/images/items/{recipe[3]}.png";
                    Recipe.InputQuantity1 = $"{recipe[4]}/min";

                    Recipe.Input2 = $"/images/items/{recipe[5]}.png";
                    Recipe.InputQuantity2 = $"{recipe[6]}/min";
                    break;
                case 3:
                    Recipe.Input1 = $"/images/items/{recipe[3]}.png";
                    Recipe.InputQuantity1 = $"{recipe[4]}/min";

                    Recipe.Input2 = $"/images/items/{recipe[5]}.png";
                    Recipe.InputQuantity2 = $"{recipe[6]}/min";

                    Recipe.Input3 = $"/images/items/{recipe[7]}.png";
                    Recipe.InputQuantity3 = $"{recipe[8]}/min";
                    break;
                case 4:
                    Recipe.Input1 = $"/images/items/{recipe[3]}.png";
                    Recipe.InputQuantity1 = $"{recipe[4]}/min";

                    Recipe.Input2 = $"/images/items/{recipe[5]}.png";
                    Recipe.InputQuantity2 = $"{recipe[6]}/min";

                    Recipe.Input3 = $"/images/items/{recipe[7]}.png";
                    Recipe.InputQuantity3 = $"{recipe[8]}/min";

                    Recipe.Input4 = $"/images/items/{recipe[9]}.png";
                    Recipe.InputQuantity4 = $"{recipe[10]}/min";
                    break;
                default:
                    break;
            }

            int CalcCounter = (InputsCounter * 2) + 3;
            switch (OutputsCounter)
            {
                case 1:
                    Recipe.Output1 = $"/images/items/{recipe[CalcCounter + 1]}.png";
                    Recipe.OutputQuantity1 = $"{recipe[CalcCounter + 2]}/min";
                    break;
                case 2:
                    Recipe.Output1 = $"/images/items/{recipe[CalcCounter + 1]}.png";
                    Recipe.OutputQuantity1 = $"{recipe[CalcCounter + 2]}/min";

                    Recipe.Output2 = $"/images/items/{recipe[CalcCounter + 3]}.png";
                    Recipe.OutputQuantity2 = $"{recipe[CalcCounter + 4]}/min";
                    break;
            }

            int AlternateCounter = (InputsCounter * 2) + (OutputsCounter * 2) + 4;
            if (recipe[AlternateCounter] == "n")
            {
                Recipe.AlternateRecipeIndicator = "Normal";
            }
            else if (recipe[AlternateCounter] == "a")
            {
                Recipe.AlternateRecipeIndicator = "Alternate";
            }
            else
            {
                Recipe.AlternateRecipeIndicator = "Error";
            }

            return Recipe;
        }

        // Function to ask for an Item that should be produced
        static string askForItem()
        {
            Console.Write("Item: ");
            string item = Console.ReadLine();
            return item;
        }

        // Function to create a readable string from a recipe in the database
        // structure of singleRecipe { int countInputs, int countOutputs, char inputIndicator, string input1, int neededQuantity1, ..., char outputIndicator, string output1, int neededQuantity1, ..., char alternareRecipeIndicator, int machineNumber }
        static string makeString(string[] singleRecipe)
        {
            int length = singleRecipe.GetLength(0); // Save length of array
            bool inputs = false;                    // set variable for inputIndicator to false
            bool outputs = false;                   // set variable for outputIndicator to false
            string text = "";
            for (int i = 0; i < length; i++) // Loop through the whole array
            {
                if (singleRecipe[i] == "a") // Check for the alternateRecipeIndicator (alternate recipe)
                {
                    int machine = Convert.ToInt32(singleRecipe[i + 1]); // Get machineNumber
                    text = text + $" Recipe Type: Alternate, Machine: {machines[machine]}"; // Add string to <text> 
                    inputs = false;  // Disable printing for inputs
                    outputs = false; // Disable printing for outputs
                    i++;
                }
                if (singleRecipe[i] == "n") // Check for the alternateRecipeIndicator (normal recipe)
                {
                    int machine = Convert.ToInt32(singleRecipe[i + 1]); // Get machineNumber
                    text = text + $" Recipe Type: Normal, Machine: {machines[machine]}"; // Add string to <text>
                    inputs = false;  // Disable printing for inputs
                    outputs = false; // Disable printing for outputs
                    i++;
                }
                if (singleRecipe[i] == "i") // Check for the inputIndicator
                {
                    text = text + "Inputs: ";
                    inputs = true; // Enable printing for inputs
                    i++;
                }
                if (singleRecipe[i] == "o") // Check for the outputIndicator
                {
                    text = text + " Outputs: ";
                    inputs = false; // Disable printing for inputs
                    outputs = true; // Enable printing for outputs
                    i++;
                }
                if (inputs || outputs) // Check if printing is enabled
                {
                    text = text + singleRecipe[i] + ", "; // Add inputs/outputs to <text>
                }
            }

            return text; // Return readable recipe 
        }

        // Function to delete empty strings ("") in an one dimensional array
        static string[] deleteEmpty1D(string[] array)
        {
            int counter = array.GetLength(0);
            for (int i = 0; i < array.GetLength(0); i++) // Loop through every element in the array
            {
                if (string.IsNullOrEmpty(array[i])) // Check if the element is empty 
                {
                    counter = i; // Save the length of the array that is filled
                    break;
                }
            }
            Array.Resize(ref array, counter); // Shrink the array to its last filled element

            return array;
        }

        // Function to delete empty strings ("") in an two dimensional array
        public static string[,] deleteEmpty2D(string[,] array)
        {
            int counter = array.GetLength(0);
            for (int i = 0; i < array.GetLength(0); i++) // Loop through every line in the array
            {
                if (string.IsNullOrEmpty(array[i, 0])) // Check if the first element of this line is empty
                {
                    counter = i; // Save the line of the array that is filled
                    break;
                }
            }
            string[,] newArray = new string[counter, array.GetLength(1)]; // Create a new shrinked array
            for (int i = 0; i < newArray.GetLength(0); i++) // Loop through every line in the newArray
            {
                for (int j = 0; j < newArray.GetLength(1); j++) // Loop through every element in the line
                {
                    newArray[i, j] = array[i, j]; // Save the data from the old array to the new shrinked array
                }
            }
            return newArray;
        }

        // Function to print full one dimesional Array 
        public static void printArray1D(string[] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                Debug.Write(array[i] + " ");
            }
        }

        // Function to print full two dimesional Array
        public static void printArray2D(string[,] array, double multiplier = 1)
        {
            //Console.WriteLine();
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    Debug.Write(array[i, j] + " ");
                }
                Debug.WriteLine("");
            }
        }

        // Function to get a one dimensional array slice from a two dimensional array
        // (example) structure array { { string someString1, string someString1, ..., }, 
        //                             { string someString2, string someString2, ..., } }
        //                             ...
        static string[] getSlice(string[,] array, int index)
        {
            int colum = array.GetLength(1);     // Get length of the searched array
            string[] slice = new string[colum]; // Create new array with the saved length
            for (int i = 0; i < colum; i++)     // Copy all elements from the original array
            {                                   //  to the new Array at the specified index
                slice[i] = array[index, i];
            }
            return slice; // (example, if index = 0) structure slice { string someString1, string someString1, ..., }
        }

        // Function to get full recipe from recipe coordinations
        // structure of coords { int machine, int lineInDatabase}
        static string[] getSingleRecipe(string[] coords)
        {
            string machine = machines[Convert.ToInt32(coords[0])]; // Save machine from coords
            string[,] recipes = loadFile(machine); // Load all recipies for the searched machine
            string[] singleRecipe = getSlice(recipes, Convert.ToInt32(coords[1])); // Load the needed recipe 
            singleRecipe = deleteEmpty1D(singleRecipe);
            Array.Resize(ref singleRecipe, singleRecipe.GetLength(0) + 1); // Make recipe bigger to add needed machine
            singleRecipe[singleRecipe.GetLength(0) - 1] = coords[0];       // Add the needed machine for the recipe to the recipe
            return singleRecipe; // structure of singleRecipe { int countInputs, int countOutputs, char inputIndicator, string input1, int neededQuantity1, ..., char outputIndicator, string output1, int neededQuantity1, ..., char alternareRecipeIndicator, int machineNumber }
        }

        // Function to create a two dimensional array with all outputs 
        //structure of coords { int machine, int lineInDatabase }
        static string[,] getOutputs(string[] coords)
        {
            string[] singleRecipe = getSingleRecipe(coords);     // Load recipe to fetch the outputs from it
            int outputsCount = Convert.ToInt32(singleRecipe[1]); // Get number of outputs from the <singleRecipe>
            string[,] outputs = new string[outputsCount, 2];     // Create a new array to save the outputs
            int counter = 0;
            while (true) // Search and save the outputs (string item, int quantity)
            {
                if (singleRecipe[counter] == "o") // Look for outputIndicator
                {
                    counter++;                    // Move to the first needed item
                    for (int i = 0; i < outputsCount; i++) // Loop through the first dimension of the array (number of outputs)
                    {
                        for (int j = 0; j < 2; j++)        // Loop through the second dimension of the array (item and quantity) (always two)
                        {
                            outputs[i, j] = singleRecipe[counter + i + j]; // Save item and quantity to <outputs>
                        }
                        counter++; // Skip quantity of the first item. Moving on to the second item
                    }
                    break; // End the loop when finished
                }
                counter++; // Look in the next index for the outputIndicator
            }

            return outputs;  // structure of outputs { { string item1, int quantity1 },
        }                    //                        { string item2, int quantity2 } }
                             //                        ...

        // Function to create a two dimensional array with all inputs
        // structure of coords { int machine, int lineInDatabase }
        static string[,] getInputs(string[] coords)
        {
            string[] singlerecipe = getSingleRecipe(coords);     // Load recipe to fetch the input from it
            int outputsCount = Convert.ToInt32(singlerecipe[0]); // Get number of inputs from the <singleRecipe>
            string[,] outputs = new string[outputsCount, 2];     // Create a new array to save the outputs
            int counter = 0;
            while (true) // Search and save the outputs (string item, int quantity)
            {
                if (singlerecipe[counter] == "i") // Look for inputIndicator
                {
                    counter++;                    // Move to the first needed item
                    for (int i = 0; i < outputsCount; i++) // Loop through the first dimension of the array (number of inputs)
                    {
                        for (int j = 0; j < 2; j++)        // Loop through the second dimension of the array (item and quantity) (always two)
                        {
                            outputs[i, j] = singlerecipe[counter + i + j]; // Save item and quantity to <outputs>
                        }
                        counter++; // Skip quantity of the first item. Moving on to the second item
                    }
                    break; // End the loop when finished
                }
                counter++; // Look in the next index for the outputIndicator
            }
            outputs = deleteEmpty2D(outputs);
            return outputs; // structure of outputs { { string item1, int quantity1 },
        }                   //                        { string item2, int quantity2 } }
                            //                        ...

        // Function to get all coordinations of the available recipes for <item>
        public static string[,] searchrecipes(string item)
        {
            int counter = 0;
            string[,] recipes = new string[10, 2]; // Create new array to save all found recipes
            for (int i = 0; i < 9; i++)            // Loop through every machine
            {
                string[,] machine = loadFile(machines[i]); // Load recipes from a single machine

                for (int j = 0; j < machine.GetLength(0); j++)     // Loop through all recipes
                {
                    for (int k = 0; k < machine.GetLength(1); k++) // Loop through every element in a single recipe
                    {
                        int output = Convert.ToInt32(machine[j, 1]); // Load countOutputs
                        if (output > 1) // Check if there are one or two outputs (only those two options are possible!)
                        {
                            for (int l = 1; l <= 3; l += 2) // Loop through output1 and output2 of the recipe 
                            {
                                if (machine[j, k] == "o" && (machine[j, k + l] == item || machine[j, k + l] == item)) // Check if the fetched item matches the searched <item>
                                {
                                    recipes[counter, 0] = i.ToString(); // Save machine as a coordinate 
                                    recipes[counter, 1] = j.ToString(); // Save line of the recipe as a coordinate
                                    counter++; // Check the next recipe
                                }
                            }
                        }
                        else
                        {
                            if (machine[j, k] == "o" && machine[j, k + 1] == item) // Check if the fetched item matches the searched <item>
                            {
                                recipes[counter, 0] = i.ToString(); // Save machine as a coordinate 
                                recipes[counter, 1] = j.ToString(); // Save line of the recipe as a coordinate
                                counter++; // Check the next recipe
                            }
                        }
                    }
                }
            }
            //recipes[counter + 1, 0] = "e";

            return recipes; // structure of recipes { { int machine1, int lineInDatabase1 },
        }                   //                        { int machine2, int lineInDatabase2 } }
                            //                        ...

        // Load all recipes into a two dimensional array of the file for <machine>
        static string[,] loadFile(string machine)
        {
            string recipesPath = searchForLibary("recipes");  // Get the path of the folder the recipes are saved in 
            string filename = recipesPath + machine + ".txt"; // Create the path to the maschine from  which the recipes should be loaded
            string[] lines = File.ReadAllLines(@filename);    // Get all lines (recipes) from the file (maschine) 
            int length_lines = lines.Length;
            string[,] list = new string[length_lines, 17];    // Create array to save the recipes

            int k = 0;
            foreach (string line in lines) // Loop through every line (recipe) 
            {
                string[] thisline = line.Split(", ", 40); // Split every line at ", " to get their inputs, outputs, etc
                int l = 0;
                foreach (string word in thisline) // Loop through every element in the splited line (recipe)
                {
                    list[k, l] = word; // Save the element at the correct place
                    l++;
                }
                k++;
            }

            return list; // structure of list { { int countInputs, int countOutputs, char inputIndicator, string input1, int neededQuantity1, ..., char outputIndicator, string output1, int neededQuantity1, ..., char alternareRecipeIndicator }, 
        }                //                     { int countInputs, int countOutputs, char inputIndicator, string input1, int neededQuantity1, ..., char outputIndicator, string output1, int neededQuantity1, ..., char alternareRecipeIndicator }, 
                         //                     ...

        // Function to search in the current directory path for a specified directory
        static string searchForLibary(string searchedDirectory)
        {
            string path = Directory.GetCurrentDirectory(); // Get the directory (path) the script is currently running in
            string[] subFolders = path.Split("\\");        // Get all folders in the path
            string testPath = "";
            string directoryPath = "";
            foreach (string item in subFolders) // Try each sub folder
            {
                testPath = testPath + item + "\\";            // Create path to try 
                directoryPath = testPath + searchedDirectory; // Add the searched folder to the path
                if (Directory.Exists(directoryPath))          // Check if the path path the searched dictionary exists
                {
                    return directoryPath + "\\";              // If it exists return it
                }
            }

            return "error"; // If it does not exists return an error
        }
    }
}
