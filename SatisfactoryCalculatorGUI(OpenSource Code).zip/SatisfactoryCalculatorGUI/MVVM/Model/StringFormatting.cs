﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace SatisfactoryCalculatorGUI.MVVM.Model
{
    public class StringFormatting
    {
        public class OnShowResultsEventArgs : EventArgs
        {
            public string CountedMachinesArgs;
            public string MachinesListArgs;
            public string MachinesTreeArgs;
            public string DefaultResourcesArgs;
            public string AllInformationArgs;
        }

        public static event EventHandler<OnShowResultsEventArgs> OnShowResults;
        public StringFormatting()
        {
            SatisfactoryCalculator.OnCalculationFinished += Testing_OnCalculationFinished;
        }

        private void Testing_OnCalculationFinished(object sender, SatisfactoryCalculator.OnCalculationFinishedEventArgs e)
        {
            string[] NeededMachines = RemoveNullArray1D(e.CountedMachines);
            string NeededMachinesInString = Array1DToString(NeededMachines);

            string[,] NeededMachinesInList = deleteEmpty2D(e.NeededMachinesInList);
            string[] NeededMachinesInList1D = EditMachinesList(NeededMachinesInList);
            string MachinesListInString = Array1DToString(NeededMachinesInList1D);

            string[,] NeededMachinesInTree = deleteEmpty2D(e.NeededMachinesInTree);
            NeededMachinesInTree = AddPerMinute(NeededMachinesInTree);
            string NeededMachinesTreeInString = Array2DToString(NeededMachinesInTree);

            string[,] NeededDefaultResources = deleteEmpty2D(e.ProducedQuantitys);
            NeededDefaultResources = AddPerMinute(NeededDefaultResources);
            string NeededDefaultResourcesInString = Array2DToString(NeededDefaultResources);

            string AllInformation = $"Diagram\n{NeededMachinesTreeInString}\n\nAll Recipes\n{MachinesListInString}\n\nResources\n{NeededDefaultResourcesInString}\n\nAll Machines\n{NeededMachinesInString}";

            OnShowResultsEventArgs ShowResultsEA = new OnShowResultsEventArgs
            {
                CountedMachinesArgs = NeededMachinesInString,
                MachinesListArgs = MachinesListInString,
                MachinesTreeArgs = NeededMachinesTreeInString,
                DefaultResourcesArgs = NeededDefaultResourcesInString,
                AllInformationArgs = AllInformation
            };

            OnShowResults?.Invoke(this, ShowResultsEA);
        }

        public string[] EditMachinesList(string[,] array)
        {
            //string[] machines = new string[] { "Smelter", "Foundry", "Constructor", "Assembler", "Manufacturer", "Refinery", "Blender", "Particle Accelerator", "Packager" };
            //string[] machines = new string[] { "Particle Accelerator", "Blender", "Refinery", "Manufacturer", "Assembler", "Constructor", "Foundry", "Smelter", "Packager" };
            string[] machines = new string[] { "Manufacturer", "Particle Accelerator", "Blender", "Assembler", "Constructor", "Refinery", "Foundry", "Smelter", "Packager" };
            
            string[] newarray = new string[array.GetLength(0)];
            int counter = 0;

            for (int i = 0; i < machines.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(0); j++)
                {
                    string SingleMachine = array[j, 0].Split(":")[0];
                    if (SingleMachine == machines[i])
                    {
                        string oneline;
                        if (array[j, 1] == "1")
                        {
                            oneline = $"{array[j, 1]} {array[j, 0].Split(":")[0]} for {array[j, 0].Split(":")[1]}";
                        }
                        else
                        {
                            oneline = $"{array[j, 1]} {array[j, 0].Split(":")[0]}s for {array[j, 0].Split(":")[1]}";
                        }
                        newarray[counter] = oneline;
                        counter++;
                    }
                }
            }

            return newarray;
        }

        public string[,] AddPerMinute(string[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                array[i, 1] += "/min";
            }

            return array;
        }

        public string Array2DToString(string[,] array)
        {
            string output = "";
            for (int i = 0; i < array.GetLength(0); i++)
            {
                string oneline = "";
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    oneline += array[i, j] + " ";
                }

                if (i == array.GetLength(0) - 1)
                {
                    output += oneline;
                }
                else
                {
                    output += oneline + "\n";
                }
            }
            
            return output;
        }

        public string Array1DToString(string[] array)
        {
            string output = "";
            for (int i = 0; i < array.GetLength(0); i++)
            {
                if (i == array.GetLength(0) - 1)
                {
                    output += array[i];
                }
                else
                {
                    output += array[i] + "\n";
                }
            }

            return output;
        }

        public string[] RemoveNullArray1D(string[] array)
        {
            int counter = 0;
            string[] newarray = new string[array.GetLength(0)];
            for (int i = 0; i < array.GetLength(0); i++)
            {
                if (!string.IsNullOrEmpty(array[i]))
                {
                    newarray[counter] = array[i];
                    counter++;
                }
            }

            newarray = deleteEmpty1D(newarray);

            return newarray;
        }

        static string[] deleteEmpty1D(string[] array)
        {
            int counter = array.GetLength(0);
            for (int i = 0; i < array.GetLength(0); i++) // Loop through every element in the array
            {
                if (string.IsNullOrEmpty(array[i])) // Check if the element is empty 
                {
                    counter = i; // Save the length of the array that is filled
                    break;
                }
            }
            Array.Resize(ref array, counter); // Shrink the array to its last filled element

            return array;
        }

        public static string[,] deleteEmpty2D(string[,] array)
        {
            int counter = array.GetLength(0);
            for (int i = 0; i < array.GetLength(0); i++) // Loop through every line in the array
            {
                if (string.IsNullOrEmpty(array[i, 0])) // Check if the first element of this line is empty
                {
                    counter = i; // Save the line of the array that is filled
                    break;
                }
            }
            string[,] newArray = new string[counter, array.GetLength(1)]; // Create a new shrinked array
            for (int i = 0; i < newArray.GetLength(0); i++) // Loop through every line in the newArray
            {
                for (int j = 0; j < newArray.GetLength(1); j++) // Loop through every element in the line
                {
                    newArray[i, j] = array[i, j]; // Save the data from the old array to the new shrinked array
                }
            }
            return newArray;
        }

        public double CheckNumber(string number)
        {
            if (!string.IsNullOrEmpty(number))
            {
                int counter = 0;
                foreach (char c in number)
                    if (c == '.' || c == ',') counter++;

                if (counter <= 1)
                {
                    char lastchar = number[number.Length - 1];
                    char firstchar = number[0];

                    if (firstchar == '.' || firstchar == ',' || lastchar == '.' || lastchar == ',')
                    {
                        return -1;
                    }
                    else
                    {
                        number = number.Replace('.', ',');
                        return Convert.ToDouble(number);
                    }
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;
            }
        }

        public static string ToReadableItem(string item)
        {
            string[] words = item.Split('_');
            string ReadableString = "";
            foreach (string word in words)
            {
                ReadableString = ReadableString + char.ToUpper(word[0]) + word.Substring(1) + " ";
            }

            if (ReadableString[ReadableString.Length - 1] == ' ')
            {
                ReadableString = ReadableString.Remove(ReadableString.Length - 1);
            }

            return ReadableString;
        }
    }
}
